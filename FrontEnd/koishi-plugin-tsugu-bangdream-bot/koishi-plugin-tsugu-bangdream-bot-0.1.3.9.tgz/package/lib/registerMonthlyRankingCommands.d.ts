import type { Context } from "koishi";
export declare function registerMonthlyRankingCommands(ctx: Context, config: any, observeUserTsugu: (session: any) => Promise<any>, commandConfig: any): void;
