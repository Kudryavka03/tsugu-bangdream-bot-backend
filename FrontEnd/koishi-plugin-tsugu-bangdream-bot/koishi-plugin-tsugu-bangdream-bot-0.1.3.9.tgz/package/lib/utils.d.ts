export declare function paresMessageList(list: any): any[];
export declare function tierListOfServerToString(): string;
export declare function parseTimeToMinutes(timeStr: string): number;
export declare function parseDate(str: string): Date | undefined;
export declare function checkLeftDigits(str: any): number;
export declare function stringArrayToNumberArray(strArray: any): any[];
