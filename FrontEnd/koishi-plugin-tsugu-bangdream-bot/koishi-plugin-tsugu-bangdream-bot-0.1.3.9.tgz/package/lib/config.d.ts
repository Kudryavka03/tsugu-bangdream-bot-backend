export declare const projectRoot: string;
export declare const assetsRootPath: string;
export declare const configPath: string;
export declare const carKeywordPath: string;
export declare const cacheRootPath: string;
export declare const bindingPlayerPromptWaitingTime: number;
export declare const Bestdoriurl = "https://bestdori.com";
export declare const BandoriStationurl = "https://api.bandoristation.com/";
export declare enum Server {
    jp = 0,
    en = 1,
    tw = 2,
    cn = 3,
    kr = 4
}
export declare const globalDefaultServer: Server[];
export declare const globalServerPriority: Server[];
export declare const serverNameFullList: string[];
export declare const tierListOfServer: {
    jp: number[];
    tw: number[];
    en: number[];
    kr: number[];
    cn: number[];
};
export interface tsuguUser {
    userId: string;
    platform: string;
    mainServer: Server;
    displayedServerList: Server[];
    shareRoomNumber: boolean;
    userPlayerIndex: number;
    userPlayerList: userPlayerInList[];
}
export interface userPlayerInList {
    playerId: number;
    server: Server;
}
export interface Channel {
    tsuguGacha: boolean;
}
export interface Config {
    useEasyBG: boolean;
    compress: boolean;
    bandoriStationToken: string;
    backendUrl: string;
    RemoteDBSwitch: boolean;
    RemoteDBUrl: string;
    reply: boolean;
    at: boolean;
}
export declare function getUserPlayerByUser(tsuguUser: any, server: any): any;
