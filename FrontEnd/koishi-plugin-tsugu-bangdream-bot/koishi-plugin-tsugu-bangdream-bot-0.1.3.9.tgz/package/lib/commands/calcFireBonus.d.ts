import { Config, Server } from '../config';
export interface CalcFireBonusInput {
    totalDraws?: number;
    fireBonus?: number;
    grandPrizes?: number;
}
export type CalcFireBonusParseResult = {
    ok: true;
    value: CalcFireBonusInput;
} | {
    ok: false;
    error: string;
};
export declare function parseCalcFireBonusInput(text: string | undefined | null): CalcFireBonusParseResult;
export declare function commandCalcFireBonus(config: Config, mainServer: Server, input: CalcFireBonusInput): Promise<Array<Buffer | string>>;
