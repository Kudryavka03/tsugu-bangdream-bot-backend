export declare function commandAddCutoffCache(config: any, mainServer: any, tier: any, eventId: any): Promise<(string | Buffer<ArrayBufferLike>)[]>;
export declare function commandDelCutoffCache(config: any, cutoffCacheId: any): Promise<(string | Buffer<ArrayBufferLike>)[]>;
export declare function commandCutoffCacheStatus(config: any): Promise<(string | Buffer<ArrayBufferLike>)[]>;
