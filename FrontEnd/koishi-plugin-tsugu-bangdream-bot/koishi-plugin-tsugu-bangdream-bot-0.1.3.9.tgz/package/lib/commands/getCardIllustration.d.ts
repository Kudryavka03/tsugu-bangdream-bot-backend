export declare function commandGetCardIllustration(config: any, cardId: any): Promise<(string | Buffer<ArrayBufferLike>)[]>;
