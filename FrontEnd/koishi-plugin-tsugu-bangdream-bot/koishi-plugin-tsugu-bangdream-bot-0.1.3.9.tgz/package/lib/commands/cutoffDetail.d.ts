export declare function commandCutoffDetail(config: any, mainServer: any, tier: any, eventId: any, compare: any): Promise<(string | Buffer<ArrayBufferLike>)[]>;
