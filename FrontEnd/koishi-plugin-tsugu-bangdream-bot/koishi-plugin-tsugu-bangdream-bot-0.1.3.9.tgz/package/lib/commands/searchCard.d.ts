export declare function commandCard(config: any, displayedServerList: any, text?: string, mainServer?: any): Promise<(string | Buffer<ArrayBufferLike>)[]>;
