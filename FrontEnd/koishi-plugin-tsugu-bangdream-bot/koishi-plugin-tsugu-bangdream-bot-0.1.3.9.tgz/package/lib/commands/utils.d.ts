export declare function generateVerifyCode(): any;
export declare function isInteger(char: any): boolean;
