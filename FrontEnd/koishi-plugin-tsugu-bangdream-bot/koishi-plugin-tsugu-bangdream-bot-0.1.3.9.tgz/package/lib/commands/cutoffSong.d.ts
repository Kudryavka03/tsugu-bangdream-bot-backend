export declare function commandCutoffSong(config: any, mainServer: any, tier: any, eventId: any): Promise<(string | Buffer<ArrayBufferLike>)[]>;
