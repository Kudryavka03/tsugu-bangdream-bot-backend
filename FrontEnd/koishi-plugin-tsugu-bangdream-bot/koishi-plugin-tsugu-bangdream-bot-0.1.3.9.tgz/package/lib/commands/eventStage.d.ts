export declare function commandEventStage(config: any, mainServer: any, eventId: any, index: any, date: any, meta?: boolean): Promise<(string | Buffer<ArrayBufferLike>)[]>;
