export declare function commandSearchPlayer(config: any, playerId: any, mainServer: any): Promise<(string | Buffer<ArrayBufferLike>)[]>;
