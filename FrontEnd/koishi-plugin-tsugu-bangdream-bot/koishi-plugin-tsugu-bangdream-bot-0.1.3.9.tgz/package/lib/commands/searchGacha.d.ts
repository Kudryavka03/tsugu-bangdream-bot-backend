export declare function commandGacha(config: any, displayedServerList: any, gachaId: any): Promise<(string | Buffer<ArrayBufferLike>)[]>;
