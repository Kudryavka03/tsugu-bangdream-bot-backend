export declare function commandCutoffAll(config: any, mainServer: any, eventId: any): Promise<(string | Buffer<ArrayBufferLike>)[]>;
