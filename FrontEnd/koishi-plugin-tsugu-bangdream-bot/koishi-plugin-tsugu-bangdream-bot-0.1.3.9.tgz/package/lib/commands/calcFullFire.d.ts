export type FullFireServer = 'jp' | 'en' | 'tw' | 'cn' | 'kr';
export interface FullFireInput {
    currentFire: number;
    remainingSeconds: number;
    server: FullFireServer;
}
export type FullFireParseResult = {
    ok: true;
    value: FullFireInput;
} | {
    ok: false;
    error: string;
};
export declare function parseFullFireInput(text: string | undefined | null): FullFireParseResult;
export declare function parseRecoveryTime(text: string): number | null;
export declare function calculateFullFireTime(input: FullFireInput, now?: Date): Date;
export declare function commandCalcFullFire(text: string | undefined | null, now?: Date): string;
export declare function getMaxFire(server: FullFireServer): number;
