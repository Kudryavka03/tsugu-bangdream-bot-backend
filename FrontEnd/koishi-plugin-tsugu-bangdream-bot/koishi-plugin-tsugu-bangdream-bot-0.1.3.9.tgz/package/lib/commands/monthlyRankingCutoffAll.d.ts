import { Server } from "../types/Server";
import { Config } from '../config';
export declare function commandMonthlyRankingCutoffAll(config: Config, mainServer: Server, monthlyRankingId: number): Promise<Array<Buffer | string>>;
