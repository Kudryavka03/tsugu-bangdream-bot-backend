import { Server } from "../types/Server";
import { Config } from '../config';
export declare function commandMonthlyRankingTopRateDetail(config: Config, monthlyRankingId: number, day: number, limit: string, count: number, playerId: string, tier: number, mainServer: Server): Promise<Array<Buffer | string>>;
