export declare function commandRoomList(config: any, keyWord: any): Promise<(string | Buffer<ArrayBufferLike>)[]>;
