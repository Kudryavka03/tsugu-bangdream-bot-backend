export declare function commandSong(config: any, displayedServerList: any, text?: string, mainServer?: any): Promise<(string | Buffer<ArrayBufferLike>)[]>;
