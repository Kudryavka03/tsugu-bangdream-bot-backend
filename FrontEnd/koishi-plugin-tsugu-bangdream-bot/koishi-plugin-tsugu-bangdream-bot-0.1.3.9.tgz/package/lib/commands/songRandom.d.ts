export declare function commandSongRandom(config: any, mainServer: any, text: any): Promise<(string | Buffer<ArrayBufferLike>)[]>;
