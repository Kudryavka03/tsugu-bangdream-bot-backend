import { Server } from "../types/Server";
import { Config } from '../config';
export declare function commandSongTop10(config: Config, mainServer: Server, eventId?: number, songId?: number): Promise<Array<Buffer | string>>;
