export declare function commandCharacter(config: any, displayedServerList: any, text: any): Promise<(string | Buffer<ArrayBufferLike>)[]>;
