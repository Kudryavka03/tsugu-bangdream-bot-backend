export declare function commandSongChart(config: any, displayedServerList: any, songId: any, difficultyId: any, mirror?: boolean): Promise<(string | Buffer<ArrayBufferLike>)[]>;
