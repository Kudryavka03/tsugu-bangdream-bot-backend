export declare function commandSongMeta(config: any, displayedServerList: any, mainServer: any, searchCondition: any): Promise<(string | Buffer<ArrayBufferLike>)[]>;
