import { Server } from "../types/Server";
import { Config } from '../config';
export declare function commandMonthlyRankingTopTenMinuteSpeed(config: Config, mainServer: Server, time: number, date: Date, allPlayer: boolean): Promise<Array<Buffer | string>>;
