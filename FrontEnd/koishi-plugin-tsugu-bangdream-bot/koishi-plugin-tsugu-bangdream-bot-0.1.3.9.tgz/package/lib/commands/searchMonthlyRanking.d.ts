export declare function commandMonthlyRanking(config: any, displayedServerList: any, text: any): Promise<(string | Buffer<ArrayBufferLike>)[]>;
