export interface NoteCountSearchInput {
    noteCount: number;
    searchText: string;
}
export type NoteCountParseResult = {
    ok: true;
    value: NoteCountSearchInput;
} | {
    ok: false;
    error: string;
};
export declare function parseNoteCountInput(input: string | undefined | null): NoteCountParseResult;
