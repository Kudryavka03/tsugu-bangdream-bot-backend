export declare function commandEvent(config: any, displayedServerList: any, text?: string, mainServer?: any): Promise<(string | Buffer<ArrayBufferLike>)[]>;
