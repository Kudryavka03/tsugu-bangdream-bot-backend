import { Server } from "../types/Server";
import { Config } from '../config';
export declare function commandMonthlyRankingTopRateRanking(config: Config, mainServer: Server, length: number, date: Date, compareTier?: number, compareUid?: number): Promise<Array<Buffer | string>>;
