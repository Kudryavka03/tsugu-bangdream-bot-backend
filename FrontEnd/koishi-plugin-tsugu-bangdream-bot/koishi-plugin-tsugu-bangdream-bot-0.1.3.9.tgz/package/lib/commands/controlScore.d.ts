import { Config, Server } from '../config';
export interface ControlScoreInput {
    targetPt: number;
    bonusRate?: number;
    eventId?: number;
    supportBand?: number;
    cpClear?: boolean;
    isWin?: boolean;
    easyMode?: boolean;
    alternativePage?: number;
    serverName?: string;
}
export type ControlScoreParseResult = {
    ok: true;
    value: ControlScoreInput;
} | {
    ok: false;
    error: string;
};
export declare const CONTROL_SCORE_GUIDE: string;
export declare function commandControlScore(config: Config, mainServer: Server, input: ControlScoreInput): Promise<Array<Buffer | string>>;
export declare function parseControlScoreInput(text: string | undefined | null): ControlScoreParseResult;
