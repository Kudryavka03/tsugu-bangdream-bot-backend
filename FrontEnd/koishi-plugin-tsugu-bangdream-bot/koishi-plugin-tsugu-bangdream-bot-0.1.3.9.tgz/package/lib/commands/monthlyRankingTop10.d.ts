import { Server } from "../types/Server";
import { Config } from '../config';
export declare function commandMonthlyRankingTop10(config: Config, mainServer: Server, monthlyRankingId?: number): Promise<Array<Buffer | string>>;
