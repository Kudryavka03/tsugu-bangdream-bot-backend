import { Server } from "../types/Server";
import { Config } from '../config';
export declare function commandMonthlyRankingTopSleepStat(config: Config, monthlyRankingId: number, playerId: string, tier: number, time: number, mainServer: Server): Promise<Array<Buffer | string>>;
