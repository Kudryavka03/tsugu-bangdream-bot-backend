export declare function commandCutoffListOfRecentEvent(config: any, mainServer: any, tier: any, eventId: any): Promise<(string | Buffer<ArrayBufferLike>)[]>;
