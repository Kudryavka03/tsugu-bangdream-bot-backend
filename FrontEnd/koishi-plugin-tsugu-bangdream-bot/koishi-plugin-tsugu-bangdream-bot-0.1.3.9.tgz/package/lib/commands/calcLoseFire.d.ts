export declare function commandCalcLoseFire(config: any, mainServer: any, song1: any, song2: any, diff1: any, diff2: any): Promise<(string | Buffer<ArrayBufferLike>)[]>;
export declare function parseCalcLoseFireInput(config: any, text: any): Promise<{
    song1: any;
    diff1: any;
    song2: any;
    diff2: any;
}>;
export { commandCalcLoseFire };
