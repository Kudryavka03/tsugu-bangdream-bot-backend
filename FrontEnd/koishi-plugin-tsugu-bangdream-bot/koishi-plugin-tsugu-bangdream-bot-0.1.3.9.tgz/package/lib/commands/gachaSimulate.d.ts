export declare function commandGachaSimulate(config: any, mainServer: any, times: number, gachaId: any): Promise<(string | Buffer<ArrayBufferLike>)[]>;
