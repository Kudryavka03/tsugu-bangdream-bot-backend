export declare function getUser(session: any, config: any): Promise<any>;
export declare function commandBindPlayer(config: any, session: any, server: any): Promise<any>;
export declare function commandUnbindPlayer(config: any, session: any, server: any, index: any): Promise<any>;
export declare function commandPlayerInfo(config: any, session: any, index: any): Promise<any>;
export declare function commandPlayerList(config: any, session: any): Promise<any>;
export declare function commandSwitchPlayerIndex(config: any, session: any, index: any): Promise<any>;
export declare function commandSwitchServerMode(config: any, session: any, server: any): Promise<any>;
export declare function commandSwitchDisplayedServerList(config: any, session: any, serverName: any): Promise<any>;
export declare function commandSwitchShareRoomNumberMode(config: any, session: any, mode: any): Promise<any>;
