export declare function roomNumber(config: any, session: any, user: any, number: any, raw_message: any): Promise<void>;
