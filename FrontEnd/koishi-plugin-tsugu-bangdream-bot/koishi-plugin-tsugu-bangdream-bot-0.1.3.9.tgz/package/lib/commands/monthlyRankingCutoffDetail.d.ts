import { Server } from "../types/Server";
import { Config } from '../config';
export declare function commandMonthlyRankingCutoffDetail(config: Config, mainServer: Server, tier: number, monthlyRankingId: number): Promise<Array<Buffer | string>>;
