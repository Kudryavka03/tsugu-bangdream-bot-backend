export declare class Room {
    constructor({ number, rawMessage, source, userId, time, avatarUrl, userName }: {
        number: any;
        rawMessage: any;
        source: any;
        userId: any;
        time: any;
        avatarUrl: any;
        userName: any;
    });
    setPlayer(player: any): void;
}
export declare function queryAllRoom(): Promise<any[]>;
export declare function queryRoomNumberFromBandoriStation(): Promise<any[]>;
export declare function submitRoomNumber({ number, rawMessage, source, userId, time, userName, bandoriStationToken, avatarUrl }: {
    number: any;
    rawMessage: any;
    source: any;
    userId: any;
    time: any;
    userName: any;
    bandoriStationToken: any;
    avatarUrl: any;
}, userpPlayerInList: any): Promise<void>;
