export declare class Player {
    constructor(playerId: any, server: any);
    initFull(useCache?: boolean, mode?: number): Promise<void>;
}
