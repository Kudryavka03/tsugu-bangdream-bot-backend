import * as config_1 from "../config";
export declare const serverList: number[];
export declare enum Server {
    jp = 0,
    en = 1,
    tw = 2,
    cn = 3,
    kr = 4
}
export declare function getServerByName(name: any): any;
export declare function getServerByPriority(content: any, displayedServerList?: config_1.Server[]): config_1.Server;
export declare function isServer(server: any): boolean;
export declare function isServerList(serverList: any): boolean;
