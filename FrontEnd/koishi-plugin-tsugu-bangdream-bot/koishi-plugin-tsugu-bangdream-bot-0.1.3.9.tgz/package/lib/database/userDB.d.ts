export declare function updateUser(session: any, update: any): Promise<void>;
export declare function updateUserPlayerList(session: any, bindingAction: any, tsuguUserServer: any, verifyed: any): Promise<void>;
export declare function isPartialTsuguUser(obj: any): boolean;
export declare function isUserPlayerInList(obj: any): boolean;
export declare function getUserPlayerByUser(tsuguUser: any, server: any, index: any): any;
