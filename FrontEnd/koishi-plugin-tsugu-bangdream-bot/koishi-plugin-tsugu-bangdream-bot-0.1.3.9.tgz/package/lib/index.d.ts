import type { Context } from "koishi";
import type { Server } from "./types/Server";
import * as koishi_1 from "koishi";
declare module 'koishi' {
    interface User {
        tsugu: {
            userId: string;
            platform: string;
            mainServer: Server;
            displayedServerList: Server[];
            shareRoomNumber: boolean;
            userPlayerIndex: number;
            userPlayerList: {
                playerId: number;
                server: Server;
            }[];
        };
    }
    interface Channel {
        tsugu_gacha: boolean;
        tsugu_run: boolean;
    }
}
export interface Config {
    useEasyBG: boolean;
    compress: boolean;
    bandoriStationToken: string;
    backendUrl: string;
    RemoteDBSwitch: boolean;
    RemoteDBUrl: string;
    noSpace: boolean;
    reply: boolean;
    at: boolean;
}
export declare const name = "tsugu-bangdream-bot";
export declare const inject: string[];
export declare const Config: koishi_1.Schema<Schemastery.ObjectS<{}>, {} & koishi_1.Dict>;
export declare function apply(ctx: Context, config: Config): void;
export declare const cmdConfig: {
    checkUnknown: boolean;
    checkArgCount: boolean;
    handleError: (err: any, { command }: {
        command: any;
    }) => string;
};
