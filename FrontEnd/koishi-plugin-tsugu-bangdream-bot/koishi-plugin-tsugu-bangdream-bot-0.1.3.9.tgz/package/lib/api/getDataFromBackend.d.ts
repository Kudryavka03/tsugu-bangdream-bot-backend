import * as koishi_1 from "koishi";
export declare const getDataFromBackendLogger: koishi_1.Logger;
export declare function getDataFromBackend(url: any, data: any): Promise<any>;
