export declare function getFuzzySearchResult(config: any, text: any): Promise<any>;
export declare function serverNameFuzzySearchResult(config: any, serverNameText: any): Promise<any>;
export declare function bandNameFuzzySearchResult(config: any, serverNameText: any): Promise<any>;
