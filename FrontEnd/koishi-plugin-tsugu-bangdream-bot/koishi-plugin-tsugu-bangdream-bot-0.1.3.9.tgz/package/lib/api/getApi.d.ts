export declare function callAPIAndCacheResponse(url: any, cacheTime?: number): Promise<any>;
