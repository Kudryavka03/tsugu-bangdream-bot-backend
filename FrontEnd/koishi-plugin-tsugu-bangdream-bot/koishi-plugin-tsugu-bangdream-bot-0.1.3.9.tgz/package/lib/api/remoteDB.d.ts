import * as koishi_1 from "koishi";
export declare const remoteDBLogger: koishi_1.Logger;
export declare function getRemoteDBUserData(RemoteDBUrl: any, platform: any, userId: any): Promise<any>;
export declare function changeUserData(RemoteDBUrl: any, platform: any, userId: any, update: any): Promise<any>;
export declare function bindPlayerRequest(RemoteDBUrl: any, platform: any, userId: any): Promise<any>;
export declare function bindPlayerVerify(RemoteDBUrl: any, platform: any, userId: any, server: any, playerId: any, bindingAction: any): Promise<any>;
