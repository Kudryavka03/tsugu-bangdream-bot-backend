import * as koishi_1 from "koishi";
export declare const getReplyFromBackendLogger: koishi_1.Logger;
export declare function getReplyFromBackendOld(url: any, data: any): Promise<any[]>;
export declare function getReplyFromBackend(url: string, data: unknown): Promise<Array<string | Buffer>>;
