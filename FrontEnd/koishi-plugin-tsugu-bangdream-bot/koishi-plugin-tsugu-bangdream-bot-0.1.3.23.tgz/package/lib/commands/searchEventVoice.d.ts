export declare function commandEventVoice(config: any, session: any, text: string, mainServer: any): Promise<void>;
