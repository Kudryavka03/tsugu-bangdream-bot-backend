export declare function commandSong(config: any, displayedServerList: any, text?: string, mainServer?: any): Promise<(string | Buffer<ArrayBufferLike>)[]>;
export declare function commandSongDiff(config: any, mainServer: any, text: any, sourceServer?: any, destinationServer?: any): Promise<(string | Buffer<ArrayBufferLike>)[]>;
