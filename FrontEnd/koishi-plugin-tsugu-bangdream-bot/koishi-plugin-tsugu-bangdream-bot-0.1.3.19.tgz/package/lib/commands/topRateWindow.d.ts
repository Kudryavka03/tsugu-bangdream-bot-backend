import { Server } from '../types/Server';
type ActivityTimeWindow = {
    from?: number;
    to?: number;
};
type ActivityTimeInputWindow = {
    from?: string;
    to?: string;
};
export declare function splitActivityTimeRange(text: string): Required<ActivityTimeInputWindow> | undefined;
export declare function joinActivityTimeRangeArgs(args: string[]): string[];
export declare function resolveActivityTimeWindow(options: ActivityTimeInputWindow, range: ActivityTimeInputWindow | undefined, server: Server): {
    ok: true;
    value: ActivityTimeWindow;
} | {
    ok: false;
    error: string;
};
export declare function parseActivityTimeWindow(fromText: string | undefined, toText: string | undefined, server: Server, now?: Date): {
    ok: true;
    value: ActivityTimeWindow;
} | {
    ok: false;
    error: string;
};
export {};
