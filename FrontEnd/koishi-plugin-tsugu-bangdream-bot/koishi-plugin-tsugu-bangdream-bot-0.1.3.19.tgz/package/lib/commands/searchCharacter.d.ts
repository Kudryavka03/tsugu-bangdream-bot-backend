export declare function commandCharacter(config: any, displayedServerList: any, text?: string, mainServer?: any): Promise<(string | Buffer<ArrayBufferLike>)[]>;
