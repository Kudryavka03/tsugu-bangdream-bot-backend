export declare function commandCutoffSong(config: any, mainServer: any, tier: any, eventId: any, songId?: any): Promise<(string | Buffer<ArrayBufferLike>)[]>;
